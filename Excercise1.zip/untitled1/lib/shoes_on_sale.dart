import 'package:flutter/material.dart';

class ShoesOnSale extends StatelessWidget {
  final String shoeName;
  final String logoImagePath;

  ShoesOnSale({
    required this.shoeName,
    required this.logoImagePath,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Container(
        padding: EdgeInsets.all(12),
        decoration: BoxDecoration(
            color: Colors.grey[200],
            border: Border.all(color: Colors.white),
            borderRadius: BorderRadius.circular(8),
        ),
        child: Row(children: [
          Container(
            height: 80,
            padding: EdgeInsets.all(12),
            color: Colors.grey[300],
            child: Image.asset(logoImagePath),
            ),
          Column(
            children: [
              Container(
              height: 30,
              width: 100,
              child: Text(shoeName),
              ),
            ]
          )
          ],
        ),
      ),
    );
  }
}
