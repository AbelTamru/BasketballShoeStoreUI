import 'package:flutter/material.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';
import 'package:untitled1/homepage.dart';

class Screen extends StatefulWidget {
  const Screen({Key? key}) : super(key: key);

  @override
  State<Screen> createState() => _ScreenState();
}

class _ScreenState extends State<Screen> {
  PageController _controller = PageController();
  bool onLastPage = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          PageView(
            controller:_controller,
            onPageChanged: (index){
              setState((){
                onLastPage = (index == 2);
              });
            },
            children: [
              Container(
                color: Colors.orange,
                child: Center(child: Text(
                    'BasketBall Clearance''\n             Store',
                    style: TextStyle(
                      fontSize: 25.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    )
                 )
                ),
          ),
          Container(
            color: Colors.blue,
            child: Center(child: Text(
                'Welcome',
                style: TextStyle(
                  fontSize: 28.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                )
              )
            ),
          ),
          Container(
            color: Colors.white,
            child: Center(child: Text(
                'WELCOME',
                style: TextStyle(
                  fontSize: 28.0,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                )
             )
            ),
          ),
        ],
      ),
          Container(
            alignment: Alignment(0,0.85),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                GestureDetector(
                  onTap: (){
                    _controller.jumpToPage(2);
                  },
                    child: Text('Skip',
                        style: TextStyle(
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2.0,
                          color: Colors.black,
                        )
                    ),
                ),
                SmoothPageIndicator(controller: _controller, count: 3),

                onLastPage
                    ? GestureDetector(
                    onTap: (){
                    Navigator.push(context, MaterialPageRoute(
                        builder: (context){
                      return HomePage();
                        },
                      ),
                    );
                },
                    child: Text('Done',
                        style: TextStyle(
                          fontSize: 18.0,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 2.0,
                          color: Colors.black,
                        )
                    ),
                )
                    : GestureDetector(
                  onTap: ()
    {
      _controller.nextPage(
        duration: Duration(milliseconds: 500),
        curve: Curves.easeIn,
      );
    },
      child: Text('Next',
          style: TextStyle(
            fontSize: 18.0,
            fontWeight: FontWeight.bold,
            letterSpacing: 2.0,
            color: Colors.black,
          )),
                ),
              ],
            ),
          ),
     ],
    ),
    );

  }
}
