import 'package:flutter/material.dart';
import 'package:untitled1/screen.dart';
import 'package:untitled1/latest_shoes.dart';
import 'package:untitled1/shoes_on_sale.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(height: 35,),
         Padding(
           padding: const EdgeInsets.only(left: 25.0),
            child: Container(
            height: 50,
            padding: EdgeInsets.all(10),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white),
              borderRadius: BorderRadius.circular(12),
              color: Colors.grey[300],
            ),
            child: Image.asset('assets/icons/left_menu.png',
            color: Colors.grey[800],
             ),
            ),
         ),
          SizedBox(height: 10,),
          Padding(
            padding: const EdgeInsets.only(left: 300.0, bottom: 0),
            child: Container(
              height: 50,
              padding: EdgeInsets.all(10),
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white),
                borderRadius: BorderRadius.circular(12),
                color: Colors.grey[300],
              ),
              child: Image.asset('assets/icons/R.png',
                color: Colors.grey[800],
              ),
            ),
          ),
          Padding(
              padding: const EdgeInsets.only(left: 50.0),
              child: Text('Search Any BasketBall Shoe',
              style: TextStyle(fontWeight: FontWeight.bold,
              fontSize: 24,
               ),
              ),
           ),
          SizedBox(height: 25),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25.0),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.grey[200],
                border: Border.all(color: Colors.white),
                borderRadius: BorderRadius.circular(12),
              ),

              child:Row(
                children: [
                  Container(
                    height: 25,
                    padding: const EdgeInsets.only(left: 30.0),
                    child: Image.asset('assets/icons/search.png',
                    ),
                    color: Colors.grey[200],
                  ),
                  Expanded(
                    child: TextField(
                      decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Search for a basketball shoe ...',
                      ),
                    ),
                  ),
                ],
              )
            )
          ),
          SizedBox(height: 50),

          Padding(
            padding: const EdgeInsets.only(left: 102.0),
            child: Text('Latest Shoe Releases',
              style: TextStyle(fontWeight: FontWeight.bold,
                fontSize: 24,
              ),
            ),
          ),
          SizedBox(height: 25),

          Container(
            height: 200,
            child: ListView.builder(
              itemCount: 3,
              scrollDirection: Axis.horizontal,
              itemBuilder: (context, index){
              return LatestShoe(
                logoImagePath: 'assets/images/lebron19.jpg',
              );
              },
           ),
          ),
          SizedBox(height: 50),

          Padding(
            padding: const EdgeInsets.only(left: 125.0),
            child: Text(
              'Shoes On Sale',
              style: TextStyle(fontWeight: FontWeight.bold,
                fontSize: 24,
              ),
            ),
          ),

          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: ListView.builder(
                  itemBuilder: (context,index){
              return ShoesOnSale(
                shoeName: 'HyperDunks 17',
                logoImagePath: 'assets/images/hyperdunks.jpg',
              );
          }),
            ),
          )
        ],
      ),
    );
  }
}
