import 'package:flutter/material.dart';

class LatestShoe extends StatelessWidget {
  final String logoImagePath;

  LatestShoe({
    required this.logoImagePath,
});

  @override
  Widget build(BuildContext context){
    return Padding(
        padding: const EdgeInsets.only(left: 25.0),
        child: Container(
          width: 200,
          padding: EdgeInsets.all(12),
          color: Colors.grey[200],
          child: Column(
          children: [
           Row(
             mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                height: 170,
                child: Image.asset(logoImagePath),
              ),
               ],
              )
            ],
          ),
        )
      );
    }
}